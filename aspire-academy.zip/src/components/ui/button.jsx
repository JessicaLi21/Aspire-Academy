export function Button({ children, className, type = "button" }) {
  return (
    <button type={type} className={`bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-xl ${className}`}>
      {children}
    </button>
  );
}